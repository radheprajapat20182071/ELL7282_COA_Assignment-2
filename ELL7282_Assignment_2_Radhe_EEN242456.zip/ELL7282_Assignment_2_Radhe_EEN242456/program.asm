; =============================================================================
; ELL7282/ELL782 Assignment 2 - Washing-machine control program (program.asm)
; 8-bit five-stage pipelined microcontroller, 16-bit instructions (see isa.pdf)
; Every address/hex field below was produced by an assembler script from this
; source, so the listing and program.hex cannot disagree.
; =============================================================================
; PERIPHERALS (memory_map.pdf)
;   0xF0 SYS_INPUT    RO  b3 DOOR_CLOSED, b2 START, b1:0 MODE[1:0]
;   0xF1 WATER_LEVEL  RO  unsigned          0xF2 TEMP RO   0xF3 DRUM_RPM RO
;   0xF4 ACTUATOR_CTL RW  b6 BUZZER, b5 DOOR_LOCK, b4 PUMP_OUT, b3 MOTOR_DIR,
;                         b2 MOTOR_EN, b1 HEATER, b0 VALVE_IN
;   0xF5 DISPLAY      RW  0x01 Fill, 0x02 Wash, 0x03 Drain, 0x04 Spin, 0xFF Done
;   0xF6 TIMER_COUNT RO | 0xF7 TIMER_LIMIT RW | 0xF8 TIMER_CTRL RW (b1 CLR pulse, b0 EN)
;   0xF9 TIMER_STATUS RO  b1 TRIP (mirror), b0 MATCH (sticky)
;
; MODE PARAMETERS (MODE is sampled once together with START/DOOR and stored in RAM[0x00])
;   MODE = 00  Quick : fill target 50 (0x32), wash 40 ticks (0x28), spin 20 ticks (0x14)
;   MODE != 00 Heavy : fill target 100 (0x64), wash 80 ticks (0x50), spin 40 ticks (0x28)
;   (tests use MODE = 00 and MODE = 01).  Drain threshold = 10 (0x0A) in both modes.
;
; REGISTER USE  R0 address pointer | R1 data/actuator value | R2,R3,R4 temporaries
;               R5 fill target | R6 wash interval | R7 spin interval
;   (R5/R6 are reused as temporaries in the wash loop after their last use.)
;   Every register is written (LDI) before it is read; the only RAM byte used is
;   RAM[0x00], written before any use. Load-use and branch hazards are handled
;   by the pipeline hardware, so no software NOPs are needed.
;
; COMPARISONS (unsigned, safe against overshoot - no equality tests on WATER_LEVEL)
;   fill : SLTU level,target -> 1 while level < target; exit when level >= target
;   drain: SLTU threshold,level -> 1 while threshold < level; exit when level <= threshold
; =============================================================================

; --- Initialisation: every actuator off, DISPLAY clear, timer cleared and disabled ---
INIT:
    LDI  R0, 0xF4         ; 0x00: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x00         ; 0x01: [1200] R1 = 0
    ST   R1, [R0]         ; 0x02: [7200] all actuator requests off
    LDI  R0, 0xF5         ; 0x03: [10F5] R0 -> DISPLAY
    ST   R1, [R0]         ; 0x04: [7200] DISPLAY = 0x00
    LDI  R0, 0xF8         ; 0x05: [10F8] R0 -> TIMER_CTRL
    LDI  R1, 0x02         ; 0x06: [1202] CLR=1, EN=0
    ST   R1, [R0]         ; 0x07: [7200] clear COUNT and MATCH, timer disabled

; --- Step 1: wait for START=1 and DOOR_CLOSED=1 (one SYS_INPUT sample), latch MODE, lock door ---
WAIT_START:
    LDI  R0, 0xF0         ; 0x08: [10F0] R0 -> SYS_INPUT
    LD   R2, [R0]         ; 0x09: [6400] R2 = SYS_INPUT sample  (b3 DOOR_CLOSED, b2 START, b1:0 MODE)
    LDI  R3, 0x0C         ; 0x0A: [160C] mask DOOR_CLOSED | START
    AND  R3, R2           ; 0x0B: [5680] isolate the two bits
    ADDI R3, 0xF4         ; 0x0C: [86F4] R3 = R3 - 0x0C  (0 only when both bits are 1)
    BNEZ R3, WAIT_START   ; 0x0D: [A608] keep waiting
    LDI  R4, 0x03         ; 0x0E: [1803] mask MODE[1:0]
    AND  R4, R2           ; 0x0F: [5880] R4 = MODE snapshot (0..3) from the same sample
    LDI  R0, 0x00         ; 0x10: [1000] R0 -> RAM[0x00]
    ST   R4, [R0]         ; 0x11: [7800] latch MODE in RAM[0x00]; never re-read from the pins
    BNEZ R4, MODE_HEAVY   ; 0x12: [A817] MODE = 00 -> Quick, MODE != 00 -> Heavy

MODE_QUICK:
    LDI  R5, 0x32         ; 0x13: [1A32] fill target  = 50
    LDI  R6, 0x28         ; 0x14: [1C28] wash interval = 40 ticks
    LDI  R7, 0x14         ; 0x15: [1E14] spin interval = 20 ticks
    JMP  LOCK_FILL        ; 0x16: [B01A] skip the Heavy parameters
MODE_HEAVY:
    LDI  R5, 0x64         ; 0x17: [1A64] fill target  = 100
    LDI  R6, 0x50         ; 0x18: [1C50] wash interval = 80 ticks
    LDI  R7, 0x28         ; 0x19: [1E28] spin interval = 40 ticks

; --- Step 2: lock door, open inlet valve, fill until unsigned WATER_LEVEL >= target ---
LOCK_FILL:
    LDI  R0, 0xF4         ; 0x1A: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x20         ; 0x1B: [1220] DOOR_LOCK
    ST   R1, [R0]         ; 0x1C: [7200] command the door lock first
    LDI  R1, 0x21         ; 0x1D: [1221] DOOR_LOCK | VALVE_IN
    ST   R1, [R0]         ; 0x1E: [7200] then open the inlet valve
    LDI  R0, 0xF5         ; 0x1F: [10F5] R0 -> DISPLAY
    LDI  R1, 0x01         ; 0x20: [1201] status 0x01 = Fill
    ST   R1, [R0]         ; 0x21: [7200] DISPLAY = 0x01
    LDI  R0, 0xF1         ; 0x22: [10F1] R0 -> WATER_LEVEL
FILL_LOOP:
    LD   R2, [R0]         ; 0x23: [6400] R2 = WATER_LEVEL (unsigned)
    SLTU R2, R5           ; 0x24: [C540] R2 = 1 if level < target
    BNEZ R2, FILL_LOOP    ; 0x25: [A423] keep filling; exits on level >= target, even after overshoot
    LDI  R0, 0xF4         ; 0x26: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x20         ; 0x27: [1220] DOOR_LOCK only
    ST   R1, [R0]         ; 0x28: [7200] close the inlet valve

; --- Step 3: wash - alternate motor direction once per poll until the timer MATCH ---
WASH_SETUP:
    LDI  R0, 0xF5         ; 0x29: [10F5] R0 -> DISPLAY
    LDI  R1, 0x02         ; 0x2A: [1202] status 0x02 = Wash
    ST   R1, [R0]         ; 0x2B: [7200] DISPLAY = 0x02
    LDI  R0, 0xF7         ; 0x2C: [10F7] R0 -> TIMER_LIMIT
    ST   R6, [R0]         ; 0x2D: [7C00] LIMIT = wash interval
    LDI  R0, 0xF8         ; 0x2E: [10F8] R0 -> TIMER_CTRL
    LDI  R1, 0x03         ; 0x2F: [1203] CLR=1, EN=1
    ST   R1, [R0]         ; 0x30: [7200] clear and start the wash timer
    LDI  R0, 0xF4         ; 0x31: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x24         ; 0x32: [1224] motor request: DOOR_LOCK | MOTOR_EN, DIR=0
    LDI  R2, 0xF9         ; 0x33: [14F9] R2 -> TIMER_STATUS
    LDI  R3, 0x01         ; 0x34: [1601] MATCH mask
    LDI  R4, 0x50         ; 0x35: [1850] 0x24 + 0x2C: toggles R1 between 0x24 and 0x2C
WASH_LOOP:
    ST   R1, [R0]         ; 0x36: [7200] apply the current direction
    LD   R5, [R2]         ; 0x37: [6A80] R5 = TIMER_STATUS
    MOV  R6, R4           ; 0x38: [2D00] R6 = 0x50
    SUB  R6, R1           ; 0x39: [4C40] R6 = 0x50 - R1  (the other direction)
    MOV  R1, R6           ; 0x3A: [2380] flip direction for the next pass
    AND  R5, R3           ; 0x3B: [5AC0] isolate MATCH
    BEQZ R5, WASH_LOOP    ; 0x3C: [9A36] repeat until MATCH = 1
    LDI  R0, 0xF4         ; 0x3D: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x20         ; 0x3E: [1220] DOOR_LOCK only
    ST   R1, [R0]         ; 0x3F: [7200] stop the wash motor
    LDI  R0, 0xF8         ; 0x40: [10F8] R0 -> TIMER_CTRL
    LDI  R1, 0x02         ; 0x41: [1202] CLR=1, EN=0
    ST   R1, [R0]         ; 0x42: [7200] clear and disable the timer

; --- Step 4: drain until unsigned WATER_LEVEL <= 10 (tested as 10 < level, so skipping past 10 is safe) ---
DRAIN_PHASE:
    LDI  R0, 0xF5         ; 0x43: [10F5] R0 -> DISPLAY
    LDI  R1, 0x03         ; 0x44: [1203] status 0x03 = Drain
    ST   R1, [R0]         ; 0x45: [7200] DISPLAY = 0x03
    LDI  R0, 0xF4         ; 0x46: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x30         ; 0x47: [1230] DOOR_LOCK | PUMP_OUT
    ST   R1, [R0]         ; 0x48: [7200] pump on
    LDI  R0, 0xF1         ; 0x49: [10F1] R0 -> WATER_LEVEL
    LDI  R3, 0x0A         ; 0x4A: [160A] drain threshold = 10
DRAIN_LOOP:
    LD   R2, [R0]         ; 0x4B: [6400] R2 = WATER_LEVEL
    MOV  R4, R3           ; 0x4C: [28C0] R4 = threshold
    SLTU R4, R2           ; 0x4D: [C880] R4 = 1 if threshold < level (still above)
    BNEZ R4, DRAIN_LOOP   ; 0x4E: [A84B] keep draining until level <= threshold
    LDI  R0, 0xF4         ; 0x4F: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x20         ; 0x50: [1220] DOOR_LOCK only
    ST   R1, [R0]         ; 0x51: [7200] pump off

; --- Step 5: clear/re-arm the timer and spin for the second interval ---
SPIN_PHASE:
    LDI  R0, 0xF5         ; 0x52: [10F5] R0 -> DISPLAY
    LDI  R1, 0x04         ; 0x53: [1204] status 0x04 = Spin
    ST   R1, [R0]         ; 0x54: [7200] DISPLAY = 0x04
    LDI  R0, 0xF7         ; 0x55: [10F7] R0 -> TIMER_LIMIT
    ST   R7, [R0]         ; 0x56: [7E00] LIMIT = spin interval
    LDI  R0, 0xF8         ; 0x57: [10F8] R0 -> TIMER_CTRL
    LDI  R1, 0x03         ; 0x58: [1203] CLR=1, EN=1
    ST   R1, [R0]         ; 0x59: [7200] clear MATCH/COUNT and re-arm the timer
    LDI  R0, 0xF4         ; 0x5A: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x24         ; 0x5B: [1224] DOOR_LOCK | MOTOR_EN, DIR=0
    ST   R1, [R0]         ; 0x5C: [7200] spin motor on
    LDI  R0, 0xF9         ; 0x5D: [10F9] R0 -> TIMER_STATUS
    LDI  R3, 0x01         ; 0x5E: [1601] MATCH mask
SPIN_LOOP:
    LD   R2, [R0]         ; 0x5F: [6400] R2 = TIMER_STATUS
    AND  R2, R3           ; 0x60: [54C0] isolate MATCH
    BEQZ R2, SPIN_LOOP    ; 0x61: [945F] spin until MATCH = 1

; --- Step 6: motor off first, then unlock + buzzer, DISPLAY = done, HALT ---
COMPLETE:
    LDI  R0, 0xF4         ; 0x62: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x20         ; 0x63: [1220] DOOR_LOCK only
    ST   R1, [R0]         ; 0x64: [7200] spin motor off (door still locked)
    LDI  R0, 0xF8         ; 0x65: [10F8] R0 -> TIMER_CTRL
    LDI  R1, 0x02         ; 0x66: [1202] CLR=1, EN=0
    ST   R1, [R0]         ; 0x67: [7200] timer cleared and disabled
    LDI  R0, 0xF4         ; 0x68: [10F4] R0 -> ACTUATOR_CTL
    LDI  R1, 0x40         ; 0x69: [1240] BUZZER only: valve, pump, heater, motor off; door unlocked
    ST   R1, [R0]         ; 0x6A: [7200] unlock now that the motor is off; buzzer on
    LDI  R0, 0xF5         ; 0x6B: [10F5] R0 -> DISPLAY
    LDI  R1, 0xFF         ; 0x6C: [12FF] status 0xFF = Done
    ST   R1, [R0]         ; 0x6D: [7200] DISPLAY = 0xFF
    HALT                  ; 0x6E: [D000] stop; actuators keep their last requested values (BUZZER on)
