ELL7282 / ELL782  Assignment 2

Name: - Radhe Shyam Prajapat 
Entery No: -  2025EEN2456
Mtech IEC 2nd Year

Five-stage pipelined 8-bit microcontroller for a washing machine (Logisim-Evolution)
=====================================================================================


1. CONTENTS OF THE ZIP
----------------------
washing_pipeline.circ    complete Logisim-Evolution design (top-level circuit: main)
isa.pdf                  formats, opcode map, reserved bits, custom instruction (SLTU)
architecture.pdf         block diagram, pipeline registers, forwarding/stall/flush,
                         reset/HALT, safety interlock
memory_map.pdf           peripheral addresses, bit fields, timer behaviour
program.asm              washing program (assembly, with address and hex in comments)
program.hex              ROM image of the washing program (256 words, Logisim "v2.0 raw")
listing.pdf              address / hex / assembly table of program.hex
pipeline_traces.pdf      cycle traces for assignment sections 8.2-8.4 (plus 8.1, 8.4b, 8.5)
validation.pdf           the six required test groups (expected / observed / pass-fail)
tests/                   test ROM images (.hex) and sources (.asm) used by validation.pdf:
                           t1_hazards, t2_branch_flush, t3a_ram_reserved, t3b_mmio,
                           t4_timer, t5_safety
README.txt               this file


2. SOFTWARE
-----------
Logisim-Evolution version: 3.9.0 (the circuit was built and tested with this version).
No external libraries are needed. The circuit uses only gates, splitters, tunnels, pins,
a clock, Registers, one ROM and one RAM. All arithmetic, multiplexing,
decoding, comparison and counting is built from gates in named subcircuits.

Circuit hierarchy (open from the Explorer pane on the left):
  main                 clock, input pins, output pins, one cpu_core instance
   cpu_core            the processor: stage and pipeline-register subcircuits wired by name
    IF_STAGE           PC register, PC+1 (INC8), PC mux, instruction ROM (256 x 16)
    IF_ID              IF/ID pipeline register (valid bit + instruction)
    ID_STAGE           control decoder (CTRLDEC), register file (RF) with WB bypass
    ID_EX              ID/EX pipeline register (valid bit, 14-bit control word, operands)
    EX_STAGE           forwarding muxes, ALU, branch/HALT detection
    EX_MEM             EX/MEM pipeline register
    MEM_STAGE          address decode, data RAM (128 x 8), ACTUATOR_CTL, DISPLAY,
                       read mux; contains TIMER and SAFETY
    MEM_WB             MEM/WB pipeline register
    HAZARD             load-use stall, flush, HALT latch, PC/IF-ID/ID-EX control
  library blocks: FA, ADD8, INC8, MUX2_8, DEC3, DEC4, EQ3, EQ8, ORR8, ALU, RF, CTRLDEC,
                  TIMER, SAFETY


3. LOADING A PROGRAM
--------------------
The washing program is already loaded in the circuit. To load a different image (for the
test programs in tests/):
1. In the Explorer pane open  cpu_core  and then  IF_STAGE.
2. Right-click the ROM labelled IROM and choose "Load Image...".
3. Select the .hex file (program.hex or one of tests/*.hex). All images are Logisim
   "v2.0 raw" files: a header line followed by 256 hexadecimal 16-bit words.
4. Go back to  main  and apply RESET (section 4).
Do not preload the data RAM (inside MEM_STAGE). RAM and registers are unspecified after
reset; every program initialises what it uses. (If Logisim asks whether to replace the
ROM contents, answer yes. To keep the original, re-load program.hex afterwards.)


4. CLOCK AND RESET
------------------
Clock:  the Clock component labelled CLK in main drives every register.
        Simulate > Auto-Tick Enabled (Alt+K) runs it; Simulate > Auto-Tick Frequency sets
        the speed (about 8 Hz is comfortable for changing inputs by hand).
        With auto-tick off, Simulate > Manual Tick Full Cycle (Alt+F9) advances exactly one
        clock cycle (one rising edge); Manual Tick Half Cycle (Alt+T) toggles the clock once,
        so two half cycles = one cycle. Use manual ticks for single-stepping and for the
        "clock paused" step in validation group 5.
        (Older Logisim versions call these items "Ticks Enabled" and "Tick Once"; the
        behaviour is the same.)
Reset:  active-high pin RESET in main (asynchronous clear of all state elements).
        1) set RESET = 1   2) give at least one rising edge   3) set RESET = 0.
        Reset sets PC = 0, invalidates every pipeline entry, clears the halted latch,
        ACTUATOR_CTL, DISPLAY, the timer (EN, COUNT, LIMIT, MATCH), the TRIP latch and the
        previous-START flip-flop.
Cycle numbering used in pipeline_traces.pdf and validation.pdf: cycle 1 is the first
clock cycle after RESET is released (PC = 0 in IF).


5. INPUT PINS (change them with the Poke tool)
----------------------------------------------
  RESET            active-high reset
  START            start request (level)
  MODE[1:0]        wash mode, 2-bit pin labelled MODE
  DOOR_CLOSED      1 = door/lid closed
  WATER_LEVEL      8-bit unsigned water level
  TEMP             8-bit temperature readback (readable only)
  DRUM_RPM         8-bit drum speed readback (readable only)

Packing seen by software (memory_map.pdf):
  0xF0 SYS_INPUT = b3 DOOR_CLOSED | b2 START | b1:0 MODE      0xF1 WATER_LEVEL
  0xF2 TEMP      0xF3 DRUM_RPM
Example: START = 1, MODE = 10, DOOR_CLOSED = 1 reads as 0x0E.

Sampling rule: inputs are read in the MEM stage of a valid LD. Keep every input stable
through that clock edge (change inputs while auto-tick is off, or well away from a rising
edge). The washing program snapshots MODE once, together with START and DOOR_CLOSED, and
stores it in RAM[0x00]; later changes of MODE do not affect the running cycle.

MODE settings used by the washing program:
  MODE = 00        Quick : fill target 50,  wash 40 ticks, spin 20 ticks
  MODE = 01        Heavy : fill target 100, wash 80 ticks, spin 40 ticks
  MODE = 10, 11    behave like Heavy (any non-zero MODE)
  Drain threshold = 10 in both modes. A "tick" of the program timer is one clock cycle.


6. OUTPUT PINS (all visible in main)
------------------------------------
Commanded outputs (ACTUATOR_CTL register 0xF4): VALVE_IN, HEATER, MOTOR_EN (request),
MOTOR_DIR, PUMP_OUT, DOOR_LOCK, BUZZER; DISPLAY (8 bits, register 0xF5); ACT (all 7
request bits as one value).
Safety-gated output:  ACTUAL_MOTOR_EN = MOTOR_EN AND DOOR_CLOSED AND NOT TRIP
(combinational; observe it separately from the requested MOTOR_EN).
Debug probes:
  PC (8 bits), STALL (load-use stall), FLUSH (taken branch/jump or HALT), HALTED,
  IFID_V / IDEX_V / EXMEM_V / MEMWB_V (pipeline valid bits), TRIP,
  COUNT (8), MATCH, LIMIT (8), TIMER_EN (timer state),
  FWDA_P1 / FWDA_P2 / FWDB_P1 / FWDB_P2 (forwarding sources for operands A and B:
  P1 = EX/MEM, P2 = MEM/WB; both can be 1, P1 has priority),
  R0_OUT ... R7_OUT (register file contents, 8 bits each).
RAM contents: open cpu_core > MEM_STAGE, right-click the RAM labelled DRAM and choose
"Edit Contents..." (also works while simulating).


7. RUNNING THE WASHING PROGRAM (validation group 6)
---------------------------------------------------
1. Inputs: DOOR_CLOSED = 1, START = 0, MODE = 00, WATER_LEVEL = 0.
2. Apply RESET (section 4), enable auto-tick (about 8 Hz).
3. Set START = 1. The program locks the door (ACTUATOR_CTL = 0x20 -> DOOR_LOCK), opens the
   valve (0x21), and shows DISPLAY = 0x01 (fill).
4. Raise WATER_LEVEL stepwise, holding each value for at least 12 clocks:
   0, 20, 40, 49, then jump straight to 53 (target 50 is skipped, never equalled).
   The valve closes shortly after the jump; DISPLAY = 0x02; the motor alternates direction
   (ACT 0x24 / 0x2C, MOTOR_DIR toggling) for 40 ticks, then stops; DISPLAY = 0x03, pump on.
5. Lower WATER_LEVEL: 53, 40, 27, 14, then jump to 1 (threshold 10 is skipped).
   The pump stops; DISPLAY = 0x04; the spin runs for 20 ticks.
6. Completion: motor off, then unlock + buzzer (ACT = 0x40 -> only BUZZER), DISPLAY = 0xFF,
   HALTED = 1.
7. Repeat with MODE = 01. Fill: 0, 20, 40, 60, 80, 99, then jump to 102 (target 100 skipped).
   Drain: 102, 76, 50, 24, 11 (still draining), then 0.
   Optional: change MODE right after START is accepted; nothing should change.
Opening DOOR_CLOSED during the motor phases triggers the safety interlock (section 9).
Wash and spin last a fixed number of clocks; do not change sensors during them.


8. RUNNING THE VALIDATION TESTS
-------------------------------
Each row of validation.pdf names its ROM image, initial inputs, procedure, expected and
observed results. Common procedure: load the image (section 3), set the listed inputs,
apply RESET, run.
  Group 1   tests/t1_hazards.hex       inputs: DOOR_CLOSED = 1, others 0
            run until HALTED = 1 (about 20 clocks); read R0_OUT..R7_OUT and RAM
  Group 2   tests/t2_branch_flush.hex  inputs: DOOR_CLOSED = 1, others 0
            watch the actuator outputs stay 0; HALTED asserts only at the last HALT
  Group 3a  tests/t3a_ram_reserved.hex inputs: DOOR_CLOSED = 1, WATER_LEVEL = 0x2A
  Group 3b  tests/t3b_mmio.hex         inputs: START = 1, MODE = 10, DOOR_CLOSED = 1,
                                       WATER_LEVEL = 0x6C, TEMP = 0x37, DRUM_RPM = 0x64
  Group 4   tests/t4_timer.hex         inputs: DOOR_CLOSED = 1; watch COUNT/MATCH/STALL;
            run to HALTED (cycle 329) and keep ticking to see COUNT continue
  Group 5   tests/t5_safety.hex        follow steps 0-8 of validation.pdf group 5
            (door opened with auto-tick off, START and MODE[0] as listed)
  Group 6   program.hex                section 7 above
The observed values printed in validation.pdf were read from this circuit in
Logisim-Evolution 3.9.0 by a scripted run (inputs set, clock toggled, outputs and RAM read
back). Repeat the procedures in the GUI and compare; add screenshots if required.
To re-create the traces of pipeline_traces.pdf: load a short ROM with the listed program
(its register/RAM pre-loads can be done with a few LDI/ST instructions in front) and
compare the stage, valid-bit, STALL/FLUSH and forwarding probes cycle by cycle.


9. SAFETY INTERLOCK NOTES
-------------------------
ACTUAL_MOTOR_EN = MOTOR_EN AND DOOR_CLOSED AND NOT TRIP. Opening the door drops it at once
(no clock, no software). TRIP sets at the clock edge where DOOR_CLOSED = 0 and
MOTOR_EN = 1, stays set when the door recloses, and clears only when MOTOR_EN = 0,
DOOR_CLOSED = 1 and a new low-to-high START edge is seen by the hardware edge detector
(previous-START flip-flop). TIMER_STATUS[1] mirrors TRIP. The washing program does not
handle trips: after a trip the motor stays disabled until the conditions above are met (in
the washing program that happens naturally between the wash and the spin if START is
toggled). This is an educational interlock, not a certified appliance safety system.


10. KNOWN BEHAVIOUR / LIMITATIONS
---------------------------------
- Load-use hazards, branch flushes and forwarding are handled by hardware; programs
  contain no software NOPs. A taken branch costs two cycles; a load-use dependence one.
- HALT does not clear the actuator requests; the washing program leaves BUZZER = 1
  and everything else off before halting.
- Unassigned opcodes 0xE and 0xF behave as NOP. Reserved instruction bits are ignored.
- Timing tests use LIMIT values well below 256; LIMIT = 0 disables the comparison.
- The circuit file is large (about 1,300 components, mostly gate-level subcircuits wired
  with named tunnels). Use the Explorer pane to move between circuits.
